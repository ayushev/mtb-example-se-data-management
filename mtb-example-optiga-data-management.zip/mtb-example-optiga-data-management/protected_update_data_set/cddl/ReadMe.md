These files can be used with respective CDDL tools as specified below.

https://tools.ietf.org/html/draft-ietf-cbor-cddl-05
Concise data definition language (CDDL): a notational convention to express CBOR and JSON data structures [Draft version]



